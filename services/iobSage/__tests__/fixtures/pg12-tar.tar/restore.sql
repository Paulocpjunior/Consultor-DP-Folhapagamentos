--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sage_folha;
--
-- Name: sage_folha; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sage_folha WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE sage_folha OWNER TO postgres;

\connect sage_folha

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: e0001; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA e0001;


ALTER SCHEMA e0001 OWNER TO postgres;

--
-- Name: e0002; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA e0002;


ALTER SCHEMA e0002 OWNER TO postgres;

--
-- Name: gen; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA gen;


ALTER SCHEMA gen OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: funcionarios; Type: TABLE; Schema: e0001; Owner: postgres
--

CREATE TABLE e0001.funcionarios (
    codigo integer NOT NULL,
    nome text,
    cpf character(11),
    admissao date,
    salario numeric(12,2),
    observacao text,
    demitido boolean,
    foto bytea
);


ALTER TABLE e0001.funcionarios OWNER TO postgres;

--
-- Name: movimento; Type: TABLE; Schema: e0001; Owner: postgres
--

CREATE TABLE e0001.movimento (
    funcionario integer,
    competencia character(6),
    evento integer,
    referencia numeric(14,6),
    valor numeric(14,2)
);


ALTER TABLE e0001.movimento OWNER TO postgres;

--
-- Name: funcionarios; Type: TABLE; Schema: e0002; Owner: postgres
--

CREATE TABLE e0002.funcionarios (
    codigo integer NOT NULL,
    nome text,
    cpf character(11),
    admissao date,
    salario numeric(12,2),
    observacao text,
    demitido boolean,
    foto bytea
);


ALTER TABLE e0002.funcionarios OWNER TO postgres;

--
-- Name: vazia; Type: TABLE; Schema: e0002; Owner: postgres
--

CREATE TABLE e0002.vazia (
    x integer
);


ALTER TABLE e0002.vazia OWNER TO postgres;

--
-- Name: empresas; Type: TABLE; Schema: gen; Owner: postgres
--

CREATE TABLE gen.empresas (
    codigo integer NOT NULL,
    cnpj character(14),
    razao text
);


ALTER TABLE gen.empresas OWNER TO postgres;

--
-- Data for Name: funcionarios; Type: TABLE DATA; Schema: e0001; Owner: postgres
--

COPY e0001.funcionarios (codigo, nome, cpf, admissao, salario, observacao, demitido, foto) FROM stdin;
\.
COPY e0001.funcionarios (codigo, nome, cpf, admissao, salario, observacao, demitido, foto) FROM '$$PATH$$/2916.dat';

--
-- Data for Name: movimento; Type: TABLE DATA; Schema: e0001; Owner: postgres
--

COPY e0001.movimento (funcionario, competencia, evento, referencia, valor) FROM stdin;
\.
COPY e0001.movimento (funcionario, competencia, evento, referencia, valor) FROM '$$PATH$$/2917.dat';

--
-- Data for Name: funcionarios; Type: TABLE DATA; Schema: e0002; Owner: postgres
--

COPY e0002.funcionarios (codigo, nome, cpf, admissao, salario, observacao, demitido, foto) FROM stdin;
\.
COPY e0002.funcionarios (codigo, nome, cpf, admissao, salario, observacao, demitido, foto) FROM '$$PATH$$/2918.dat';

--
-- Data for Name: vazia; Type: TABLE DATA; Schema: e0002; Owner: postgres
--

COPY e0002.vazia (x) FROM stdin;
\.
COPY e0002.vazia (x) FROM '$$PATH$$/2919.dat';

--
-- Data for Name: empresas; Type: TABLE DATA; Schema: gen; Owner: postgres
--

COPY gen.empresas (codigo, cnpj, razao) FROM stdin;
\.
COPY gen.empresas (codigo, cnpj, razao) FROM '$$PATH$$/2915.dat';

--
-- Name: funcionarios funcionarios_pkey; Type: CONSTRAINT; Schema: e0001; Owner: postgres
--

ALTER TABLE ONLY e0001.funcionarios
    ADD CONSTRAINT funcionarios_pkey PRIMARY KEY (codigo);


--
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: gen; Owner: postgres
--

ALTER TABLE ONLY gen.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (codigo);


--
-- PostgreSQL database dump complete
--

